from datetime import datetime, timezone
import logging
from typing import Callable

from fastapi import Request
from fastapi.responses import JSONResponse

from schemas.Response import Error, ErrorResponse, Meta
from core.exceptions import (
    BaseAppException,
    InvalidVerifyToken,
    NotExists,
    AuthenticationFailed,
    PermissionDenied,
    AlreadyExists,
    InvalidParameter,
    RateLimitExceeded,
)

logger = logging.getLogger("core.exception_handlers")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_response(
    exc: BaseAppException,
    log_func: Callable[[str], None],
    log_msg: str | None = None,
) -> JSONResponse:
    """
    根据异常构建统一的 JSON 响应格式，同时执行日志记录。

    参数：
        exc (BaseAppException): 继承自基础异常的自定义异常实例。
        log_func (Callable): 日志记录函数（如 logger.warning 或 logger.error）。
        log_msg (str | None): 日志自定义消息，默认根据异常类型和详情自动生成。

    返回：
        JSONResponse: FastAPI 的 JSON 响应对象，包含错误信息和元数据。
    """
    message = log_msg or f"{exc.__class__.__name__}: {exc.detail or exc.message}"
    log_func(message, exc_info=(log_func == logger.error))

    error_resp = ErrorResponse(
        status=exc.error_status,
        message=exc.message,
        error=Error(code=exc.code, details=exc.detail),
        meta=Meta(timestamp=now_iso()),
    )
    return JSONResponse(
        status_code=exc.http_status,
        content=error_resp.model_dump(by_alias=True, exclude_none=True),
    )


async def invalid_verify_token_handler(
    request: Request, exc: InvalidVerifyToken
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        f"令牌验证失败，令牌过期或失效: {exc.detail}",
    )


async def user_not_exists_handler(request: Request, exc: NotExists) -> JSONResponse:
    user_info = (
        f"UUID: {exc.uuid}" if getattr(exc, "uuid", None) else f"user: {exc.username}"
    )
    return build_response(
        exc,
        logger.warning,
        f"用户不存在: {user_info}: {exc.detail}",
    )


async def global_exception_handler(
    request: Request, exc: BaseAppException
) -> JSONResponse:
    return build_response(
        exc,
        logger.error,
        f"全局异常: {exc.detail or exc.message}",
    )


async def authentication_failed_handler(
    request: Request, exc: AuthenticationFailed
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        f"登录失败: 用户名或密码错误: {exc.username}",
    )


async def user_already_exists_handler(
    request: Request, exc: AlreadyExists
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        f"用户已存在: {exc.detail}",
    )


async def permission_denied_handler(
    request: Request, exc: PermissionDenied
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        "操作失败，权限不足",
    )


async def invalid_parameter_handler(
    request: Request, exc: InvalidParameter
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        "非法提交参数",
    )


async def rate_limit_exceeded_handler(
    request: Request, exc: RateLimitExceeded
) -> JSONResponse:
    return build_response(
        exc,
        logger.warning,
        "请求次数过多",
    )


exception_handler_map = {
    InvalidVerifyToken: invalid_verify_token_handler,
    NotExists: user_not_exists_handler,
    BaseAppException: global_exception_handler,
    AuthenticationFailed: authentication_failed_handler,
    AlreadyExists: user_already_exists_handler,
    PermissionDenied: permission_denied_handler,
    InvalidParameter: invalid_parameter_handler,
    RateLimitExceeded: rate_limit_exceeded_handler,
}


def register_exception_handlers(app):
    for exc_type, handler in exception_handler_map.items():
        app.add_exception_handler(exc_type, handler)
